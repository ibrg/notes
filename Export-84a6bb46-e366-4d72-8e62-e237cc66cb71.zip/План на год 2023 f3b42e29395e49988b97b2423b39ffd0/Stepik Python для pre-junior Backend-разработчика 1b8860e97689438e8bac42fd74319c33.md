# Stepik: Python для pre-junior Backend-разработчика

Date Created: January 25, 2023 1:59 PM
Status: To Do
URL: https://stepik.org/course/122813/syllabus