# Stepik: Введение в Data Science и машинное обучение

Date Created: January 25, 2023 2:02 PM
Status: To Do
URL: https://stepik.org/course/4852/syllabus