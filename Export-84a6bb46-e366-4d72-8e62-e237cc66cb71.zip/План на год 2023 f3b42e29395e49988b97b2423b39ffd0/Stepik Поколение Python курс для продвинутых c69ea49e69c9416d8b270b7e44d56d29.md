# Stepik: "Поколение Python": курс для продвинутых

Date Created: January 25, 2023 1:46 PM
Status: To Do
URL: https://stepik.org/course/68343/syllabus